/* 
 * File:   flush.h
 * Author: jcaf
 *
 * Created on July 16, 2019, 3:46 PM
 */

#ifndef FLUSHALLMODE_H
#define	FLUSHALLMODE_H


void flushAllMode_cmd(int8_t cmd);
void flushAllMode_job(void);


#ifdef	__cplusplus
extern "C" {
#endif
#ifdef	__cplusplus
}
#endif

#endif	/* FLUSHALLMODE_H */

