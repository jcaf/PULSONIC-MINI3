#include "main.h"
#include "mpap.h"
#include "pulsonic.h"

double NOZZLE_QTY_DIFF = 0.1;//inc/dec in 0.1

int8_t nozzle_isEnabled(int n)
{
    if (pulsonic.nozzle[n].Q_mlh > 0.0)
        return 1;
    return 0;
}
 
/*return the truncated current position(left adjusted)*/
int8_t nozzle_getPosition(void)
{
    return (mpap_get_numSteps_current()/MPAP_NUMSTEP_1NOZZLE);
}

static int8_t sm0;

void nozzle_setPosition_reset(void)
{
    sm0 = 0;
}

int8_t nozzle_setPosition(int8_t n)
{
    int8_t cod_ret = 0;
    int16_t numSteps_current;
    
    if (sm0 == 0)
    {
        if (n == 0)
        {
            numSteps_current = mpap_get_numSteps_current();

            if (numSteps_current != 0) //diferente del origen
            {
                if (numSteps_current<= ((NOZZLE_NUMMAX-1)*(MPAP_NUMSTEP_1NOZZLE)))
                {
                    //->18->0(arrastrando)
                    mpap_homming_job_reset();
                    sm0 = 2;
                }            
                else//se quedo a medias
                {
                    //completa con el otro metodo
                    if ( mpap_get_numSteps_current() - ((NOZZLE_NUMMAX-1)*(MPAP_NUMSTEP_1NOZZLE)) > 0)
                    {
                        //sale y completa, 
                        mpap_movetoNozzle(NOZZLE_NUMMAX);//completa el giro
                        sm0++;
                    }
                }
            }
        }
        else
        {
            //usa el metodo convencional de traslado
            sm0 = 3;
        }
    }
    else if (sm0 == 1)
    {
        if (mpap_isIdle())
        {
            mpap.numSteps_current = 0x0000;//Set to origin = 0

            //Aqui deberia de haber 1 zero
            if (PinRead(PORTRxSTEPPER_SENSOR_HOME, PINxSTEPPER_SENSOR_HOME) == 1)//Error?
            {
                pulsonic.error.f.homeSensor = 1;
                pulsonic.flags.homed = 0;
            }
            cod_ret = 0;
        }
    }
    //
    else if (sm0 == 2)
    {
        if (mpap_homming_job())
        {
            //termino
            cod_ret = 1;
        }
    }
    else if (sm0 == 3)
    {
        mpap_movetoNozzle(n);
        sm0++;
    }
    else if (sm0 == 4)
    {
        if (mpap_isIdle())
        {
            cod_ret = 1;
        }
    }
    
    return cod_ret;
}