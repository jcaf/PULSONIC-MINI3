/* 
 * File:   automode.h
 * Author: jcaf
 *
 * Created on July 11, 2019, 7:14 PM
 */

#ifndef AUTOMODE_H
#define	AUTOMODE_H
   
   void autoMode_disp7s_writeSumTotal(void);
   void autoMode_cmd(int8_t cmd);
   void autoMode_job(void);
   
void autoMode_jobX(void);
void autoMode_job_temperature(void);
    
#ifdef	__cplusplus
extern "C" {
#endif

#ifdef	__cplusplus
}
#endif

#endif	/* AUTOMODE_H */

