/* 
 * File:   flushAtNozzle.h
 * Author: jcaf
 *
 * Created on July 21, 2019, 1:44 PM
 */

#ifndef FLUSHATNOZZLE_H
#define	FLUSHATNOZZLE_H


void flushAtNozzle_setNozzle(int8_t nozzle);
void flushAtNozzle_cmd(int8_t cmd);
void flushAtNozzle_job(void);

#ifdef	__cplusplus
extern "C" {
#endif
#ifdef	__cplusplus
}
#endif

#endif	/* FLUSHATNOZZLE_H */

