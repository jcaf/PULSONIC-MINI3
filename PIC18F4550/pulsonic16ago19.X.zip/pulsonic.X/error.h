/* 
 * File:   error.h
 * Author: jcaf
 *
 * Created on July 18, 2019, 1:26 PM
 */

#ifndef ERROR_H
#define	ERROR_H

#ifdef	__cplusplus
extern "C" {
#endif

    void error_job(void);


#ifdef	__cplusplus
}
#endif

#endif	/* ERROR_H */

